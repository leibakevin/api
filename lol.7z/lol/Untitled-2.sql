-- SQLite
INSERT INTO `Blogs` (BlogId, Url)
VALUES (1,"asdasda");