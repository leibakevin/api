namespace ejercicio_LU.Model
{
    public class Editorial
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}